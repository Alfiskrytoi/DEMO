﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 fr1 = new Form1();
            fr1.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            LichDan ld1 = new LichDan();
            ld1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           MM MF = new MM();
            MF.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RPM RF = new RPM();
            RF.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SP SF = new SP();
            SF.Show();
            this.Hide();
        }
    }
}
